require.config({
    paths: {
        'oldEcharts': 'tmp/oldEcharts',
        'newEcharts': 'tmp/newEcharts'
    }
});
